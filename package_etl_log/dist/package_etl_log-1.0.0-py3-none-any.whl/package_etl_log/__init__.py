from .etl_log import add_comment
from .etl_log import create_logs
from .etl_log import get_status
from .etl_log import insert_elt_logs
from .etl_log import set_destiny_schema
from .etl_log import set_destiny_table
from .etl_log import set_filters
from .etl_log import set_info_load
from .etl_log import set_num_records
from .etl_log import set_source
from .etl_log import set_statusTrue
from .etl_log import set_statusFalse

