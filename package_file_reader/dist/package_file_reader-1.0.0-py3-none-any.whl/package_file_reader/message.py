import enum

class message_reader(enum.Enum):
    
    ERROR_SIZE_XML_TO_DICT = "Error, length of xml register less than zero."